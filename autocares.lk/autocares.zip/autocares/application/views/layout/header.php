<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top" style="background-color: #4a4a4a;">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="" class="logo d-flex align-items-center">
        <img src="<?php echo base_url(); ?>assets/img/logo.png" alt="">
        <span>AutoCares</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="">Home</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->